"""Placeholder for qgi-recipe-fleet-vintage-rollup Lambda.
Real code has not been deployed by CI/CD yet.
Same #153 pattern as the post-pass Lambda.
"""
import os

def lambda_handler(event, context):
    fn = os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "<unknown>")
    raise RuntimeError(
        f"PLACEHOLDER STUB STILL LIVE for Lambda '{fn}'. "
        f"Terraform created this function but CI/CD has not yet deployed "
        f"the real code. Trigger: `gh workflow run deploy-lambdas.yml "
        f"--repo AminAlAit/qgi-pipeline -f deploy_all=true` or push "
        f"any commit touching lambdas/recipe-fleet-vintage-rollup/."
    )
